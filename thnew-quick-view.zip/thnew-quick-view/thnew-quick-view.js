jQuery(function ($) {

    'use strict';

    /**
     * Open Quick View.
     */
    $(document).on('click', '.opn-quick-view-text', function (e) {

        e.preventDefault();

        let productID = $(this).data('product_id');

        if (!productID) {
            return;
        }

        $('.thnew-popup').fadeIn(200);

        $.ajax({

            url: thnewQuickView.ajaxurl,

            type: 'POST',

            dataType: 'json',

            data: {
                action: 'thnew_quick_view',
                product_id: productID,
                nonce: thnewQuickView.nonce
            },

            beforeSend: function () {

                $('.thnew-popup-content').html(
                    '<div class="thnew-qv-loader"></div>'
                );
            },

            success: function (response) {

                if (response.success) {

                    $('.thnew-popup-content').html(
                        response.data.html
                    );

                    initFlexSlider();

                    initVariationForms();

                    initCustomQuantity();

                    initVariationEvents();

                    initAjaxCart();
                }
            }
        });
    });

    /**
     * FLEXSLIDER.
     */
    function initFlexSlider() {

        $('.thnew-qv-thumbs').flexslider({

            animation: 'slide',

            controlNav: false,

            animationLoop: false,

            slideshow: false,

            itemWidth: 90,

            itemMargin: 12,

            asNavFor: '.thnew-qv-gallery'
        });

        $('.thnew-qv-gallery').flexslider({

            animation: 'slide',

            controlNav: false,

            animationLoop: false,

            slideshow: false,

            sync: '.thnew-qv-thumbs'
        });
    }

    /**
     * Variation Forms.
     */
    function initVariationForms() {

        $('.variations_form').each(function () {

            $(this).wc_variation_form();
        });
    }

    /**
     * Quantity.
     */
    function initCustomQuantity() {

        /**
         * Plus.
         */
        $(document).on('click', '.th-qty-plus', function () {

            let input = $(this).siblings('.custom-th-qty');

            let value = parseInt(input.val());

            input.val(value + 1).trigger('change');
        });

        /**
         * Minus.
         */
        $(document).on('click', '.th-qty-minus', function () {

            let input = $(this).siblings('.custom-th-qty');

            let value = parseInt(input.val());

            if (value > 1) {

                input.val(value - 1).trigger('change');
            }
        });

        /**
         * Sync quantity.
         */
        $(document).on('change', '.custom-th-qty', function () {

            let qty = $(this).val();

            $('#th-custom-add-to-cart').attr(
                'data-quantity',
                qty
            );
        });
    }

    /**
     * Variation Events.
     */
    function initVariationEvents() {

        /**
         * Variation found.
         */
        $('.variations_form').on(
            'found_variation',
            function (event, variation) {

                /**
                 * Update variation ID.
                 */
                $('#th-custom-add-to-cart').attr(
                    'data-variation_id',
                    variation.variation_id
                );

                /**
                 * Update price.
                 */
                if (variation.price_html) {

                    $('#th-dynamic-price').html(
                        variation.price_html
                    );
                }

                /**
                 * Update image.
                 */
                if (
                    variation.image &&
                    variation.image.full_src
                ) {

                    $('.thnew-qv-gallery')
                        .flexslider(0);

                    $('.th-gallery-image').first().attr(
                        'src',
                        variation.image.full_src
                    );
                }
            }
        );

        /**
         * Reset variation.
         */
        $('.variations_form').on(
            'reset_data',
            function () {

                $('#th-custom-add-to-cart').attr(
                    'data-variation_id',
                    0
                );
            }
        );
    }

    /**
     * AJAX Add To Cart.
     */
    function initAjaxCart() {

        $(document).on(
            'click',
            '#th-custom-add-to-cart',
            function (e) {

                e.preventDefault();

                let button = $(this);

                let productID = button.data('product_id');

                let variationID = button.data('variation_id');

                let quantity = button.data('quantity');

                let form = $('.variations_form');

                let data = {
                    product_id: productID,
                    quantity: quantity,
                    variation_id: variationID,
                    action: 'woocommerce_ajax_add_to_cart'
                };

                /**
                 * Get attributes.
                 */
                form.find('select').each(function () {

                    let attributeName = $(this).attr('name');

                    let attributeValue = $(this).val();

                    data[attributeName] = attributeValue;
                });

                button.addClass('loading');

                $.ajax({

                    url: wc_add_to_cart_params.ajax_url,

                    type: 'POST',

                    data: data,

                    success: function (response) {

                        $(document.body).trigger(
                            'added_to_cart',
                            [
                                response.fragments,
                                response.cart_hash,
                                button
                            ]
                        );

                        button.removeClass('loading');

                        $('.thnew-popup').fadeOut(200);
                    }
                });
            }
        );
    }

    /**
     * Close Popup.
     */
    function closePopup() {

        $('.thnew-popup').fadeOut(200);

        setTimeout(function () {

            $('.thnew-popup-content').html('');

        }, 300);
    }

    /**
     * Overlay.
     */
    $(document).on(
        'click',
        '.thnew-popup-overlay',
        function () {

            closePopup();
        }
    );

    /**
     * Close.
     */
    $(document).on(
        'click',
        '.thnew-popup-close',
        function () {

            closePopup();
        }
    );

    /**
     * ESC.
     */
    $(document).keyup(function (e) {

        if (27 === e.keyCode) {

            closePopup();
        }
    });
});