<?php
/**
 * THNEW Quick View.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class THNEW_Quick_View {

	public function __construct() {

		add_action(
			'wp_enqueue_scripts',
			array( $this, 'enqueue_assets' )
		);

		add_action(
			'wp_footer',
			array( $this, 'popup_markup' )
		);

		add_action(
			'wp_ajax_thnew_quick_view',
			array( $this, 'quick_view_ajax' )
		);

		add_action(
			'wp_ajax_nopriv_thnew_quick_view',
			array( $this, 'quick_view_ajax' )
		);
	}

	/**
	 * Assets.
	 */
	public function enqueue_assets() {

		wp_enqueue_style( 'flexslider' );

		wp_enqueue_script( 'flexslider' );

		wp_enqueue_script(
			'wc-add-to-cart-variation'
		);

		wp_enqueue_style(
			'thnew-quick-view',
			get_template_directory_uri() . '/thnew-quick-view/thnew-quick-view.css',
			array(),
			'1.0.0'
		);

		wp_enqueue_script(
			'thnew-quick-view',
			get_template_directory_uri() . '/thnew-quick-view/thnew-quick-view.js',
			array(
				'jquery',
				'flexslider',
				'wc-add-to-cart-variation',
			),
			'1.0.0',
			true
		);

		wp_localize_script(
			'thnew-quick-view',
			'thnewQuickView',
			array(
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'thnew_qv_nonce' ),
			)
		);
	}

	/**
	 * Popup markup.
	 */
	public function popup_markup() {
		?>

		<div class="thnew-popup">

			<div class="thnew-popup-overlay"></div>

			<div class="thnew-popup-wrapper">

				<button type="button"
						class="thnew-popup-close">

					×
				</button>

				<div class="thnew-popup-content"></div>

			</div>

		</div>

		<?php
	}

	/**
	 * AJAX.
	 */
	public function quick_view_ajax() {

		check_ajax_referer(
			'thnew_qv_nonce',
			'nonce'
		);

		$product_id = isset( $_POST['product_id'] )
			? absint( wp_unslash( $_POST['product_id'] ) )
			: 0;

		if ( empty( $product_id ) ) {

			wp_send_json_error();
		}

		$product = wc_get_product( $product_id );

		if ( ! $product ) {

			wp_send_json_error();
		}

		$gallery_ids = $product->get_gallery_image_ids();

		array_unshift(
			$gallery_ids,
			$product->get_image_id()
		);

		ob_start();
		?>

		<div class="thnew-qv-grid">

			<!-- LEFT -->
			<div class="thnew-qv-gallery-wrap">

				<div class="thnew-qv-gallery">

					<ul class="slides" id="th-gallery-wrapper">

						<?php foreach ( $gallery_ids as $image_id ) : ?>

							<?php
							$image = wp_get_attachment_image_url(
								$image_id,
								'woocommerce_single'
							);

							if ( empty( $image ) ) {
								continue;
							}
							?>

							<li>

								<img class="th-gallery-image"
									 src="<?php echo esc_url( $image ); ?>"
									 alt="">

							</li>

						<?php endforeach; ?>

					</ul>

				</div>

				<div class="thnew-qv-thumbs">

					<ul class="slides">

						<?php foreach ( $gallery_ids as $image_id ) : ?>

							<?php
							$thumb = wp_get_attachment_image_url(
								$image_id,
								'woocommerce_gallery_thumbnail'
							);

							if ( empty( $thumb ) ) {
								continue;
							}
							?>

							<li>

								<img src="<?php echo esc_url( $thumb ); ?>"
									 alt="">

							</li>

						<?php endforeach; ?>

					</ul>

				</div>

			</div>

			<!-- RIGHT -->
			<div class="thnew-qv-content">

				<h2 class="thnew-qv-title">

					<?php echo esc_html( $product->get_name() ); ?>

				</h2>

				<div class="thnew-qv-rating">

					<?php woocommerce_template_single_rating(); ?>

				</div>

				<div id="th-dynamic-price"
					 class="thnew-qv-price">

					<?php woocommerce_template_single_price(); ?>

				</div>

				<div id="th-dynamic-desc"
					 class="thnew-qv-description">

					<?php woocommerce_template_single_excerpt(); ?>

				</div>

				<div class="thnew-qv-cart-form">

					<?php
					if ( $product->is_type( 'variable' ) ) {

						woocommerce_variable_add_to_cart();
					}
					?>

					<div class="thnew-custom-cart">

						<div class="thnew-custom-qty">

							<button type="button"
									class="th-qty-minus">
								−
							</button>

							<input type="number"
								   value="1"
								   min="1"
								   class="custom-th-qty">

							<button type="button"
									class="th-qty-plus">
								+
							</button>

						</div>

						<button type="button"
								id="th-custom-add-to-cart"
								class="button"
								data-product_id="<?php echo esc_attr( $product_id ); ?>"
								data-variation_id="0"
								data-quantity="1">

							<?php
							echo esc_html__(
								'Add To Cart',
								'textdomain'
							);
							?>

						</button>

					</div>

				</div>

				<div class="thnew-qv-meta">

					<?php woocommerce_template_single_meta(); ?>

				</div>

			</div>

		</div>

		<?php

		wp_send_json_success(
			array(
				'html' => ob_get_clean(),
			)
		);
	}
}

new THNEW_Quick_View();