jQuery(function ($) {

    'use strict';

/**
 * Quantity Plus.
 */
$(document).on(
    'click',
    '.thnew-qv-plus',
    function () {

        let input =
            $(this)
                .siblings('.thnew-qv-qty');

        let value =
            parseInt(input.val()) || 1;

        input.val(value + 1);
    }
);

/**
 * Quantity Minus.
 */
$(document).on(
    'click',
    '.thnew-qv-minus',
    function () {

        let input =
            $(this)
                .siblings('.thnew-qv-qty');

        let value =
            parseInt(input.val()) || 1;

        if (value > 1) {

            input.val(value - 1);
        }
    }
);
    /**
     * Open Popup.
     */
    $(document).on('click', '.opn-quick-view-text', function (e) {

        e.preventDefault();

        let productID = $(this).data('product_id');

        if (!productID) {
            return;
        }

        $('.thnew-popup').fadeIn(200);

        $.ajax({

            url: thnewQuickView.ajaxurl,

            type: 'POST',

            dataType: 'json',

            data: {
                action: 'thnew_quick_view',
                product_id: productID,
                nonce: thnewQuickView.nonce
            },

            beforeSend: function () {

                $('.thnew-popup-content').html(
                    '<div class="thnew-qv-loader"></div>'
                );
            },

            success: function (response) {

                if (response.success) {

                    $('.thnew-popup-content').html(
                        response.data.html
                    );

                    initFlexSlider();

                   

                    initVariationLogic();
                }
            }
        });
    });

    /**
     * FlexSlider.
     */
    function initFlexSlider() {

    let galleryLength =
        $('.thnew-qv-gallery .slides li').length;

    /**
     * Main gallery.
     */
    $('.thnew-qv-gallery').flexslider({

        animation: 'slide',

        controlNav: false,

        animationLoop: false,

        slideshow: false,

        directionNav: galleryLength > 1,

        sync:
            galleryLength > 1
                ? '.thnew-qv-thumbs'
                : ''
    });

    /**
     * Thumbnails only if more than 1 image.
     */
    if (galleryLength > 1) {

        $('.thnew-qv-thumbs').show();

        $('.thnew-qv-thumbs').flexslider({

            animation: 'slide',

            controlNav: false,

            animationLoop: false,

            slideshow: false,

            itemWidth: 90,

            itemMargin: 12,

            asNavFor: '.thnew-qv-gallery'
        });

    } else {

        $('.thnew-qv-thumbs').hide();
    }
}



    /**
     * Variations.
     */
    function initVariationLogic() {

    let wrapper = $('.thnew-qv-variations');

    if (!wrapper.length) {
        return;
    }

    let variations = wrapper.data(
        'product_variations'
    );

    $('.thnew-qv-variation-select').on(
        'change',
        function () {

            let selected = {};

            let allSelected = true;

            $('.thnew-qv-variation-select').each(
                function () {

                   let attribute = $(this).attr('name');

                    let value = $(this).val();

                    if (!value) {
                        allSelected = false;
                    }

                    selected[attribute] = value;
                }
            );

            if (!allSelected) {
                return;
            }

            let matchedVariation = null;

            $.each(
                variations,
                function (index, variation) {

                    let matched = true;

                    $.each(
                        variation.attributes,
                        function (key, value) {

                            if (
                                selected[key] !== value
                            ) {
                                matched = false;
                            }
                        }
                    );

                    if (matched) {

                        matchedVariation =
                            variation;

                        return false;
                    }
                }
            );

            if (!matchedVariation) {
                return;
            }

            /**
             * Save full variation.
             */
            $('.thnew-qv-add-to-cart').data(
                'variation',
                matchedVariation
            );

            /**
             * Variation ID.
             */
            $('.thnew-qv-add-to-cart').attr(
                'data-variation_id',
                matchedVariation.variation_id
            );

            /**
             * Price.
             */
            if (matchedVariation.price_html) {

                $('.thnew-qv-price').html(
                    matchedVariation.price_html
                );
            }

            /**
             * Stock.
             */
            if (
                matchedVariation.availability_html
            ) {

                $('.thnew-qv-stock').html(
                    matchedVariation.availability_html
                );
            }

            /**
             * Image.
             */
            if (
                matchedVariation.image &&
                matchedVariation.image.full_src
            ) {

                $('.th-gallery-image')
                    .first()
                    .attr(
                        'src',
                        matchedVariation.image
                            .full_src
                    );
            }
        }
    );
}

    /**
     * AJAX Cart.
     */
    $(document).on(
    'click',
    '.thnew-qv-add-to-cart',
    function (e) {

        e.preventDefault();

        let button = $(this);

        let productID =
            button.data('product_id');

        let variationID =
            button.attr('data-variation_id') || 0;

        let quantity =
            $('.thnew-qv-qty').val();

        let data = {

            product_id: productID,

            quantity: quantity,

            variation_id: variationID
        };

        /**
         * Attributes.
         */
        $('.thnew-qv-variation-select').each(
            function () {

                let attribute = $(this).attr('name');

                    data[attribute] = $(this).val();

                         }
        );

        button.addClass('loading');

        $.ajax({

            type: 'POST',

            url:
                wc_add_to_cart_params.wc_ajax_url
                    .toString()
                    .replace(
                        '%%endpoint%%',
                        'add_to_cart'
                    ),

            data: data,

            success: function (response) {

                button.removeClass(
                    'loading'
                );

                if (
                    response.error &&
                    response.product_url
                ) {

                    window.location =
                        response.product_url;

                    return;
                }

                $(document.body).trigger(
                    'added_to_cart',
                    [
                        response.fragments,
                        response.cart_hash,
                        button
                    ]
                );

                closePopup();
            }
        });
    }
);

    /**
     * Close.
     */
    function closePopup() {

        $('.thnew-popup').fadeOut(200);

        setTimeout(function () {

            $('.thnew-popup-content').html('');

        }, 300);
    }

    /**
     * Overlay.
     */
    $(document).on(
        'click',
        '.thnew-popup-overlay',
        function () {

            closePopup();
        }
    );

    /**
     * Close Button.
     */
    $(document).on(
        'click',
        '.thnew-popup-close',
        function () {

            closePopup();
        }
    );

    /**
     * ESC.
     */
    $(document).keyup(function (e) {

        if (27 === e.keyCode) {

            closePopup();
        }
    });
});

