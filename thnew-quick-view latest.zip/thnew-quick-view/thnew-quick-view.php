<?php
/**
 * THNEW Quick View.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class THNEW_Quick_View {

	/**
	 * Constructor.
	 */
	public function __construct() {

		add_action(
			'wp_enqueue_scripts',
			array( $this, 'enqueue_assets' )
		);

		add_action(
			'wp_footer',
			array( $this, 'popup_markup' )
		);

		add_action(
			'wp_ajax_thnew_quick_view',
			array( $this, 'quick_view_ajax' )
		);

		add_action(
			'wp_ajax_nopriv_thnew_quick_view',
			array( $this, 'quick_view_ajax' )
		);
	}

	/**
	 * Assets.
	 */
	public function enqueue_assets() {

		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		wp_enqueue_style( 'flexslider' );

		wp_enqueue_script( 'flexslider' );

		wp_enqueue_script(
			'wc-add-to-cart-variation'
		);

		wp_enqueue_style(
			'thnew-quick-view',
			get_template_directory_uri() . '/thnew-quick-view/thnew-quick-view.css',
			array(),
			'1.0.0'
		);

		wp_enqueue_script(
			'thnew-quick-view',
			get_template_directory_uri() . '/thnew-quick-view/thnew-quick-view.js',
			array(
				'jquery',
				'flexslider',
				'wc-add-to-cart-variation',
			),
			'1.0.0',
			true
		);

		wp_localize_script(
			'thnew-quick-view',
			'thnewQuickView',
			array(
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'thnew_qv_nonce' ),
			)
		);
	}

	/**
	 * Popup markup.
	 */
	public function popup_markup() {
		?>

		<div class="thnew-popup">

			<div class="thnew-popup-overlay"></div>

			<div class="thnew-popup-wrapper">

				<button type="button"
						class="thnew-popup-close"
						aria-label="<?php echo esc_attr__( 'Close Popup', 'textdomain' ); ?>">

					×
				</button>

				<div class="thnew-popup-content"></div>

			</div>

		</div>

		<?php
	}

	/**
	 * AJAX.
	 */
	public function quick_view_ajax() {

		check_ajax_referer(
			'thnew_qv_nonce',
			'nonce'
		);

		$product_id = isset( $_POST['product_id'] )
			? absint( wp_unslash( $_POST['product_id'] ) )
			: 0;

		if ( empty( $product_id ) ) {

			wp_send_json_error();
		}

		$product = wc_get_product( $product_id );

		if ( ! $product ) {

			wp_send_json_error();
		}

		$layout = 'style1';

		ob_start();

		$this->render_layout(
			$product,
			$layout
		);

		wp_send_json_success(
			array(
				'html' => ob_get_clean(),
			)
		);
	}

	/**
	 * Layouts.
	 */
	private function render_layout( $product, $layout ) {

		switch ( $layout ) {

			case 'style2':

				$this->render_layout_style2( $product );

				break;

			default:

				$this->render_layout_style1( $product );

				break;
		}
	}

	/**
	 * Layout 1.
	 */
	private function render_layout_style1( $product ) {
		?>

		<div class="thnew-qv-grid">

			<!-- LEFT -->
			<div class="thnew-qv-gallery-column">

				<?php $this->render_gallery( $product ); ?>

			</div>

			<!-- RIGHT -->
			<div class="thnew-qv-summary-column">

				<?php $this->render_summary( $product ); ?>

			</div>

		</div>

		<?php
	}

	/**
	 * Layout 2.
	 */
	private function render_layout_style2( $product ) {
		?>

		<div class="thnew-qv-layout2">

			<div class="thnew-qv-layout2-gallery">

				<?php $this->render_gallery( $product ); ?>

			</div>

			<div class="thnew-qv-layout2-content">

				<?php $this->render_summary( $product ); ?>

			</div>

		</div>

		<?php
	}

	/**
	 * Gallery.
	 */
	private function render_gallery( $product ) {

		$gallery_ids = $product->get_gallery_image_ids();

		array_unshift(
			$gallery_ids,
			$product->get_image_id()
		);
		?>

		<div class="thnew-qv-gallery-wrap">

			<div class="thnew-qv-gallery">

				<ul class="slides">

					<?php foreach ( $gallery_ids as $image_id ) : ?>

						<?php
						$image = wp_get_attachment_image_url(
							$image_id,
							'woocommerce_single'
						);

						if ( empty( $image ) ) {
							continue;
						}
						?>

						<li>

							<img class="th-gallery-image"
								 src="<?php echo esc_url( $image ); ?>"
								 alt="">

						</li>

					<?php endforeach; ?>

				</ul>

			</div>

			<div class="thnew-qv-thumbs">

				<ul class="slides">

					<?php foreach ( $gallery_ids as $image_id ) : ?>

						<?php
						$thumb = wp_get_attachment_image_url(
							$image_id,
							'woocommerce_gallery_thumbnail'
						);

						if ( empty( $thumb ) ) {
							continue;
						}
						?>

						<li>

							<img src="<?php echo esc_url( $thumb ); ?>"
								 alt="">

						</li>

					<?php endforeach; ?>

				</ul>

			</div>

		</div>

		<?php
	}

	/**
	 * Summary.
	 */
	private function render_summary( $product ) {
		?>

		<div class="thnew-qv-summary-wrap">

			<h2 class="thnew-qv-title">

				<?php echo esc_html( $product->get_name() ); ?>

			</h2>

			<div class="thnew-qv-rating">

				<?php woocommerce_template_single_rating(); ?>

			</div>

			<div class="thnew-qv-price">

				<?php echo wp_kses_post( $product->get_price_html() ); ?>

			</div>

			<div class="thnew-qv-description">

				<?php
				echo wp_kses_post(
					wpautop(
						$product->get_short_description()
					)
				);
				?>

			</div>

			<?php $this->render_variations( $product ); ?>

			<?php $this->render_custom_cart( $product ); ?>

			<div class="thnew-qv-meta">

				<?php woocommerce_template_single_meta(); ?>

			</div>

		</div>

		<?php
	}

	/**
	 * Variations.
	 */
	private function render_variations( $product ) {

		if ( ! $product->is_type( 'variable' ) ) {
			return;
		}

		$attributes           = $product->get_variation_attributes();
		$available_variations = $product->get_available_variations();
		?>

		<div class="thnew-qv-variations"
			 data-product_variations="<?php echo esc_attr( wp_json_encode( $available_variations ) ); ?>">

			<?php foreach ( $attributes as $attribute_name => $options ) : ?>

				<div class="thnew-qv-variation-row">

					<label>

						<?php
						echo esc_html(
							wc_attribute_label( $attribute_name )
						);
						?>

					</label>

					<select class="thnew-qv-variation-select"
							name="attribute_<?php echo esc_attr( $attribute_name ); ?>"
							data-attribute_name="attribute_<?php echo esc_attr( $attribute_name ); ?>">

						<option value="">

							<?php
							echo esc_html__(
								'Choose an option',
								'textdomain'
							);
							?>

						</option>

						<?php foreach ( $options as $option ) : ?>

							<option value="<?php echo esc_attr( $option ); ?>">

								<?php echo esc_html( $option ); ?>

							</option>

						<?php endforeach; ?>

					</select>

				</div>

			<?php endforeach; ?>

		</div>

		<?php
	}

	/**
	 * Custom Cart.
	 */
	private function render_custom_cart( $product ) {
		?>

		<div class="thnew-qv-cart-wrap">

			<div class="thnew-qv-qty-wrap">

				<button type="button"
						class="thnew-qv-minus">

					−
				</button>

				<input type="number"
					   class="thnew-qv-qty"
					   value="1"
					   min="1">

				<button type="button"
						class="thnew-qv-plus">

					+
				</button>

			</div>

			<button type="button"
					class="thnew-qv-add-to-cart"
					data-product_id="<?php echo esc_attr( $product->get_id() ); ?>">

				<?php
				echo esc_html__(
					'Add To Cart',
					'textdomain'
				);
				?>

			</button>

		</div>

		<div class="thnew-qv-stock"></div>

		<?php
	}
}

new THNEW_Quick_View();